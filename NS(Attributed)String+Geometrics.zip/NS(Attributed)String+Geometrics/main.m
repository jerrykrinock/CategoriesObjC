//
//  main.m
//  StringDrawingMeasurer
//
//  Created by Jerry Krinock on 07/06/14.
//  Copyright __MyCompanyName__ 2007. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
