#import <Cocoa/Cocoa.h>


@interface NSView (ShowDimensions)

- (void)showGreenArrowsWithHeight:(float)overallHeight ;

@end
